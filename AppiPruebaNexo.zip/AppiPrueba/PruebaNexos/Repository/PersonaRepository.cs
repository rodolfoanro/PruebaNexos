﻿using PruebaNexos.Data;
using PruebaNexos.Models;
using PruebaNexos.Repository.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.Repository
{
    public class PersonaRepository : IPersonaRepository
    {
        private readonly ApplicationDbContext _bdOracle;

        public PersonaRepository(ApplicationDbContext bdOracle)
        {
            _bdOracle = bdOracle;
        }

        public bool CrearPersona(Persona persona)
        {
            _bdOracle.Persona.Add(persona);
            return Guardar();
        }

        public bool ExistePersona(string nombre)
        {
            bool valor = _bdOracle.Persona.Any(c => c.NOMBRE.ToLower().Trim() == nombre.ToLower().Trim());
            return valor;
        }

        public bool ExistePersona(int id_Persona)
        {
            return _bdOracle.Persona.Any(c => c.ID_PERSONA == id_Persona);
        }

        public Persona GetPersona(int Id_persona)
        {
            return _bdOracle.Persona.FirstOrDefault(c => c.ID_PERSONA == Id_persona);
        }

        public ICollection<Persona> GetPersonas()
        {
            return _bdOracle.Persona.OrderBy(c => c.NOMBRE).ToList();
        }

        public bool Guardar()
        {
            return _bdOracle.SaveChanges() >= 0 ? true : false;
        }
    }
}
