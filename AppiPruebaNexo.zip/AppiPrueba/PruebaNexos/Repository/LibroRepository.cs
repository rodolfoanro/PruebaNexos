﻿using Microsoft.EntityFrameworkCore;
using PruebaNexos.Data;
using PruebaNexos.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.Repository.Interfaz
{
    public class LibroRepository : ILibroRepository
    {
        private readonly ApplicationDbContext _bdOracle;

        public LibroRepository(ApplicationDbContext bdOracle)
        {
            _bdOracle = bdOracle;
        }

        public IEnumerable<Libro> BuscarLibro(string titulo)
        {
            IQueryable<Libro> query = _bdOracle.Libro;
            if (!string.IsNullOrEmpty(titulo))
            {
                query = query.Where(e => e.TITULO.Contains(titulo) || e.GENERO.Contains(titulo));
            }
            return query.ToList();
        }

        public bool CrearLibro(Libro libro)
        {
            _bdOracle.Add(libro);
            return Guardar();
        }

        public bool ExisteLibro(string nombre)
        {
            bool valor = _bdOracle.Libro.Any(c => c.TITULO.ToLower().Trim() == nombre.ToLower().Trim());
            return valor;
        }

        public bool ExisteLibro(int id)
        {
            return _bdOracle.Libro.Any(c => c.ID_LIBRO == id);
        }

        public Libro GetLibro(int LibroId)
        {
            return _bdOracle.Libro.FirstOrDefault(c => c.ID_LIBRO == LibroId);
        }

        public ICollection<Libro> GetLibroAutor(int PersonaId)
        {
            return _bdOracle.Libro.Include(pa => pa.PERSONA).Where(pa => pa.PERSONA_ID == PersonaId).ToList();
        }
        public ICollection<Libro> GetBuscarAutor(string nombre)
        {
            IQueryable<Libro> query = _bdOracle.Libro.Include(pa => pa.PERSONA);
            if (!string.IsNullOrEmpty(nombre))
            {
                query = query.Where(pa => pa.TITULO.Contains(nombre) || pa.GENERO.Contains(nombre)  || pa.PERSONA.NOMBRE.Contains(nombre));
            }
            return query.ToList();

           
        }
        public ICollection<Libro> GetLibros()
        {
            return _bdOracle.Libro.OrderBy(c => c.TITULO).ToList();
        }

        public bool Guardar()
        {
                return _bdOracle.SaveChanges() >= 0 ? true : false;

        }

     
    }
}
