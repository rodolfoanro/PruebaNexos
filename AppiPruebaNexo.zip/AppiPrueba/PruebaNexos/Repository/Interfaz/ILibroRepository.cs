﻿using PruebaNexos.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.Repository.Interfaz
{
    public interface ILibroRepository
    {
        ICollection<Libro> GetLibros();

        ICollection<Libro> GetLibroAutor(int PersonaId);

        ICollection<Libro> GetBuscarAutor(string nombre);

        Libro GetLibro(int LibroId);

        bool ExisteLibro(string nombre);

        IEnumerable<Libro> BuscarLibro(string titulo);

        bool ExisteLibro(int id);

        bool CrearLibro(Libro libro);

        bool Guardar();
       
    }
}
