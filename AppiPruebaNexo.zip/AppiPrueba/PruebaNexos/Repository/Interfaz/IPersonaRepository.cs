﻿using PruebaNexos.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.Repository.Interfaz
{
    public interface IPersonaRepository
    {

        ICollection<Persona> GetPersonas();

        Persona GetPersona(int Id_persona);

        bool ExistePersona(string nombre);

        bool ExistePersona(int id_Persona);

        bool CrearPersona(Persona persona);

        bool Guardar();
    }
}
