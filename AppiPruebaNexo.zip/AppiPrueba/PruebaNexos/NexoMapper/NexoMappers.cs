﻿using AutoMapper;
using PruebaNexos.Models;
using PruebaNexos.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.NexoMapper
{
    public class NexoMappers : Profile
    {
        public NexoMappers()
        {
            CreateMap<Persona, PersonaDto>().ReverseMap();
            CreateMap<Libro, LibroDto>().ReverseMap();
            CreateMap<Libro, LibroCreateDto>().ReverseMap();
        }

    }
}
