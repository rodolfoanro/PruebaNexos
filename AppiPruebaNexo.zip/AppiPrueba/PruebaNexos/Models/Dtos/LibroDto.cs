﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.Models.Dtos
{
    public class LibroDto
    {
      
        public int ID_LIBRO { get; set; }


       
        [Required (ErrorMessage ="Debe ingresar el Titulo")]
        public string TITULO { get; set; }

        [Required(ErrorMessage = "Debe ingresar Año")]
        public DateTime FECHA_PUBLICACION { get; set; }

        [Required(ErrorMessage = "Debe ingresar Genero")]
        public string GENERO { get; set; }

       
        [Required(ErrorMessage = "Debe ingresar Numero de Paginas")]
        public int NUMERO_PAGINAS { get; set; }

        public int PERSONA_ID { get; set; }

        public PersonaDto PERSONA { get; set; }

    }
}
