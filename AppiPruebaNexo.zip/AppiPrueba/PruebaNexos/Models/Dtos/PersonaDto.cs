﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.Models.Dtos
{
    public class PersonaDto
    {
       
        
        [Required (ErrorMessage ="ingrese el nombre")]
        public string NOMBRE { get; set; }

        [Required (ErrorMessage ="ingrese la fecha de nacimiento")]
        public DateTime FECHA_NACIMIENTO { get; set; }

        
        [Required (ErrorMessage = "Ingrese la ciudad de origen")]
        public string CIUDAD { get; set; }

      
        [Required (ErrorMessage ="Ingrese el correo valido")]
        public string CORREO { get; set; }
    }
}
