﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.Models
{
    public class Persona
    {
        [Key]
        [StringLength(10)]
    
        public int ID_PERSONA { get; set; }

   
        [StringLength(50)]
      
        public string NOMBRE { get; set; }

      
        public DateTime FECHA_NACIMIENTO { get; set; }

        [StringLength(50)]
     
        public string CIUDAD { get; set; }

        [StringLength(50)]

        public string CORREO { get; set; } 
    }
}
