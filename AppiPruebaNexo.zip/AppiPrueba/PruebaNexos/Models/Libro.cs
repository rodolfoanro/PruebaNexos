﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.Models
{
    public class Libro
    {
        [Key]
        [StringLength(10)]
        public int ID_LIBRO { get; set; }


        [StringLength(50)]
        public string TITULO { get; set; }

        public DateTime FECHA_PUBLICACION { get; set; }

        [StringLength(50)]
     
        public string GENERO { get; set; }

        [StringLength(50)]
    
        public int NUMERO_PAGINAS { get; set; }

        public int PERSONA_ID { get; set; }
        [ForeignKey("PERSONA_ID")]

        public Persona PERSONA { get; set; }
    }
}
