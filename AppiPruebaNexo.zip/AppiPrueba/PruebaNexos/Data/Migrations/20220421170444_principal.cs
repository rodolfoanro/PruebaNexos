﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PruebaNexos.Migrations
{
    public partial class principal : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Persona",
                columns: table => new
                {
                    ID_PERSONA = table.Column<int>(type: "NUMBER(10)", maxLength: 10, nullable: false)
                        .Annotation("Oracle:Identity", "1, 1"),
                    NOMBRE = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: false),
                    FECHA_NACIMIENTO = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: false),
                    CIUDAD = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: false),
                    CORREO = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Persona", x => x.ID_PERSONA);
                });

            migrationBuilder.CreateTable(
                name: "Libro",
                columns: table => new
                {
                    ID_LIBRO = table.Column<int>(type: "NUMBER(10)", maxLength: 10, nullable: false)
                        .Annotation("Oracle:Identity", "1, 1"),
                    TITULO = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: false),
                    FECHA_PUBLICACION = table.Column<DateTime>(type: "TIMESTAMP(7)", nullable: false),
                    GENERO = table.Column<string>(type: "NVARCHAR2(50)", maxLength: 50, nullable: false),
                    NUMERO_PAGINAS = table.Column<int>(type: "NUMBER(10)", maxLength: 50, nullable: false),
                    PERSONA_ID = table.Column<int>(type: "NUMBER(10)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Libro", x => x.ID_LIBRO);
                    table.ForeignKey(
                        name: "FK_Libro_Persona_PERSONA_ID",
                        column: x => x.PERSONA_ID,
                        principalTable: "Persona",
                        principalColumn: "ID_PERSONA",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Libro_PERSONA_ID",
                table: "Libro",
                column: "PERSONA_ID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Libro");

            migrationBuilder.DropTable(
                name: "Persona");
        }
    }
}
