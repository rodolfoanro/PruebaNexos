﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.helpers
{
    public static class Errores
    {
        public static void AddAplicationError(this HttpResponse response, string menssage)
        {
            response.Headers.Add("Application-Error", menssage);
            response.Headers.Add("Access-Control-Expose-Headers", "Application - Error");
            response.Headers.Add("Access-Control-Allow-Origin", "*");
        }
    }
}
