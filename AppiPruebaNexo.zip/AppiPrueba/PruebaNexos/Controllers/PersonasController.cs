﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PruebaNexos.Models;
using PruebaNexos.Models.Dtos;
using PruebaNexos.Repository.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.Controllers
{
    [Route("api/Personas")]
    [ApiController]
    public class PersonasController : Controller
    {
        private readonly IPersonaRepository _paRepo;
        private readonly IMapper _mapper;
        public PersonasController(IPersonaRepository paRepo, IMapper mapper)
        {
            _paRepo = paRepo;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult GetPersonas()
        {
            var ListarPersonas = _paRepo.GetPersonas();

            var ListarPersonasDto = new List<PersonaDto>();

            foreach (var lista in ListarPersonas)
            {
                ListarPersonasDto.Add(_mapper.Map<PersonaDto>(lista));
            }

            return Ok(ListarPersonasDto);
        }


        //bascamos las personas 
        [HttpGet("{PersonaId:int}", Name = "GetPersona")]
        public IActionResult GetPersona(int PersonaId)
        {
            var itemPersona = _paRepo.GetPersona(PersonaId);

            if (itemPersona == null)
            {
                return NotFound();
            }

            var itemPersonaDto = _mapper.Map<PersonaDto>(itemPersona);
            return Ok(itemPersonaDto);
        }


        [HttpPost]
        public IActionResult CreatePersona([FromBody] PersonaDto personaDto)
        {
            if (personaDto == null)
            {
                return BadRequest(ModelState);
            }
            if (_paRepo.ExistePersona(personaDto.NOMBRE))
            {
                ModelState.AddModelError("", "EL NOMBRE YA EXISTE");
                return StatusCode(404, ModelState);
            }

            var persona = _mapper.Map<Persona>(personaDto);

            if (!_paRepo.CrearPersona(persona))
            {
                ModelState.AddModelError("", $"ALGO SALIO MAL GUARDARDON EL REGISTRO{persona.NOMBRE}");
                return StatusCode(500, ModelState);
            }

            return CreatedAtRoute("GetPersona", new { PersonaId = persona.ID_PERSONA }, persona);
        }

    }
}
