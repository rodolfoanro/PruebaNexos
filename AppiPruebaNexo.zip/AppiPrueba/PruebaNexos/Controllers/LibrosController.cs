﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PruebaNexos.Models;
using PruebaNexos.Models.Dtos;
using PruebaNexos.Repository.Interfaz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaNexos.Controllers
{
    [Route("api/Libros")]
    [ApiController]
    public class LibrosController : Controller
    {
        private readonly ILibroRepository _LbRepo;
        private readonly IMapper _mapper;

        public LibrosController(ILibroRepository LbRepo, IMapper mapper)
        {
            _LbRepo = LbRepo;
            _mapper = mapper;
        }

        [HttpGet]
        public IActionResult GetLibros()
        {
            var ListarLibros = _LbRepo.GetLibros();

            var ListarLibrosDto = new List<LibroDto>();

            foreach (var lista in ListarLibros)
            {
                ListarLibrosDto.Add(_mapper.Map<LibroDto>(lista));
            }


            return Ok(ListarLibrosDto);
        }

        [HttpGet("{LibroId:int}", Name = "GetLibro")]
        public IActionResult GetLibro(int LibroId)
        {
            var itemLibro = _LbRepo.GetLibro(LibroId);

            if (itemLibro == null)
            {
                return NotFound();
            }

            var itemLibroDto = _mapper.Map<LibroDto>(itemLibro);
            return Ok(itemLibroDto);
        }

        [HttpPost]
        public IActionResult CreateLibro([FromBody] LibroCreateDto libroDto)
        {
            if (libroDto == null)
            {
                return BadRequest(ModelState);
            }
            if (_LbRepo.ExisteLibro(libroDto.TITULO))
            {
                ModelState.AddModelError("", "EL TITULO YA EXISTE");
                return StatusCode(404, ModelState);
            }

            var libro = _mapper.Map<Libro>(libroDto);

            if (!_LbRepo.CrearLibro(libro))
            {
                ModelState.AddModelError("", $"ALGO SALIO MAL GUARDARDON EL REGISTRO{libro.TITULO}");
                return StatusCode(500, ModelState);
            }

            return CreatedAtRoute("GetPersona", new { LibroId = libro.ID_LIBRO }, libro);
        }


        [HttpGet("GetLibrosConAutor/{PersonaId:int}")]
        public IActionResult GetLibrosConAutor (int PersonaId)
        {
            var ListaLibro = _LbRepo.GetLibroAutor(PersonaId);
            
            if (ListaLibro == null)
            {
                return NotFound();
            }

            var itemLibro = new List<LibroDto>();
            foreach(var item in ListaLibro)
            {
                itemLibro.Add(_mapper.Map<LibroDto>(item));
            }
            return Ok(itemLibro);
        }

        [HttpGet("BuscarAutor")]
        public IActionResult GetBuscarAutor(string nombre)
        {
            try
            {
                var resultado = _LbRepo.GetBuscarAutor(nombre);
                if (resultado.Any())
                {


                    return Ok(resultado);
                }
                return NotFound();

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error recuperando datos de la aplicacion");
            }


        }

        [HttpGet("Buscar")]
        public IActionResult Buscar(string titulo)
        {
            try
            {
                var resultado = _LbRepo.BuscarLibro(titulo);
                if (resultado.Any())
                {

                    
                    return Ok(resultado);
                }
                return NotFound();

            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error recuperando datos de la aplicacion");
            }
        }


    }
}
