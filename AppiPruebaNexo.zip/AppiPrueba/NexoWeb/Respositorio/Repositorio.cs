﻿using NexoWeb.Respositorio.Interfaz;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NexoWeb.Respositorio
{
    public class Repositorio<T> : IRepositorio<T> where T : class
    {
        public Task<bool> CrearAsync(string url, T itemActualizar)
        {
            throw new NotImplementedException();
        }

        public Task<T> GetAsync(string url, int Id)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable> GetTodoAsync(string url)
        {
            throw new NotImplementedException();
        }
    }
}
