﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NexoWeb.Utilidades
{
    public static class Constantes
    {
        public static string UrlBaseApi = "https://localhost:44389/";

        public static string RutaLibrosApi = UrlBaseApi + "api/Libros/";

        public static string RutaPersonasApi = UrlBaseApi + "api/Personas/";

    }
}
